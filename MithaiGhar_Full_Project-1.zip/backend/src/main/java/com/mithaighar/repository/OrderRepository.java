package com.mithaighar.repository;
import com.mithaighar.model.Order;
import org.springframework.data.jpa.repository.JpaRepository;
public interface OrderRepository extends JpaRepository<Order,Long>{}
