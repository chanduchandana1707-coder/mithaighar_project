package com.mithaighar;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
@SpringBootApplication
public class MithaiGharApplication {
 public static void main(String[] args){SpringApplication.run(MithaiGharApplication.class,args);}
}
