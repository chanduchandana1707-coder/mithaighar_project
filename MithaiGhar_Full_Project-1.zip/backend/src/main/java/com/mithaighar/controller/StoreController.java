package com.mithaighar.controller;
import com.mithaighar.model.*;
import com.mithaighar.repository.*;
import org.springframework.web.bind.annotation.*;
import org.springframework.http.*;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.RestController;
import java.util.*;
@RestController @RequestMapping("/api")
public class StoreController {
 private final ProductRepository products; private final OrderRepository orders;
 public StoreController(ProductRepository p,OrderRepository o){products=p;orders=o;}
 @GetMapping("/products") public List<Product> products(){return products.findAll();}
 @GetMapping("/orders") public List<Order> orders(){return orders.findAll();}
 @GetMapping("/orders/{id}") public ResponseEntity<Order> order(@PathVariable Long id){return orders.findById(id).map(ResponseEntity::ok).orElse(ResponseEntity.notFound().build());}
 @PostMapping("/orders") public ResponseEntity<?> create(@RequestBody Order input){
  if(input.customerName==null||input.customerName.isBlank()||input.phone==null||!input.phone.matches("\\\\d{10}")||input.items==null||input.items.isEmpty())return ResponseEntity.badRequest().body(Map.of("error","Please provide a name, valid 10-digit phone and at least one item."));
  double total=0;
  for(OrderItem item:input.items){if(item.quantity<1||item.unitPrice<0)return ResponseEntity.badRequest().body(Map.of("error","Invalid order item."));total+=item.quantity*item.unitPrice;}
  input.total=total;input.status="RECEIVED";input.orderNumber="MG"+System.currentTimeMillis();
  return ResponseEntity.status(HttpStatus.CREATED).body(orders.save(input));
 }
 @Bean CommandLineRunner seed(ProductRepository repo){return args->{if(repo.count()==0){
  repo.save(new Product("Royal Kaju Katli","Classics",680,"500 g",4.9,"Bestseller","Silky cashew diamonds finished with delicate silver leaf.","https://images.unsplash.com/photo-1605197161470-5d7b3f8f8f7c?auto=format&fit=crop&w=900&q=85"));
  repo.save(new Product("Motichoor Ladoo","Classics",420,"500 g",4.8,"Customer favourite","Tiny golden pearls, gently bound with fragrant syrup.","https://images.unsplash.com/photo-1601303516534-3c6c2c1b5b1e?auto=format&fit=crop&w=900&q=85"));
  repo.save(new Product("Pista Milk Cake","Signature",560,"500 g",4.9,"House special","Slow-cooked milk fudge with a pistachio finish.","https://images.unsplash.com/photo-1666190092159-3b3c1b6d5d4e?auto=format&fit=crop&w=900&q=85"));
  repo.save(new Product("Kesar Peda","Classics",390,"500 g",4.7,"Pure desi ghee","Soft, saffron-kissed peda with a nostalgic finish.","https://images.unsplash.com/photo-1631452180519-c014fe946bc7?auto=format&fit=crop&w=900&q=85"));
  repo.save(new Product("Assorted Celebration Box","Gift boxes",1290,"1 kg",5.0,"Gift-ready","A handpicked collection for celebrations.","https://images.unsplash.com/photo-1606471191009-639e3e5a2b7a?auto=format&fit=crop&w=900&q=85"));
  repo.save(new Product("Gulab Jamun","Traditional",360,"500 g",4.8,"Made fresh","Soft khoya dumplings soaked in cardamom syrup.","https://images.unsplash.com/photo-1666190092159-3b3c1b6d5d4e?auto=format&fit=crop&w=900&q=85"));
 }};}
}
