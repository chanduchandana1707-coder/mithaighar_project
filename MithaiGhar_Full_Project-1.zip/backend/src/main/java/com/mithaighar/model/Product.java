package com.mithaighar.model;
import jakarta.persistence.*;
@Entity
public class Product {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 public String name,category,weight,tag,description,image;
 public double price,rating;
 public int stock=30;
 public Product(){}
 public Product(String n,String c,double p,String w,double r,String t,String d,String i){name=n;category=c;price=p;weight=w;rating=r;tag=t;description=d;image=i;}
}
