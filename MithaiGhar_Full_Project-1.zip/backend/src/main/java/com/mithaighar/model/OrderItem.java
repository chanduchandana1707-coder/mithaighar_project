package com.mithaighar.model;
import jakarta.persistence.*;
@Entity
public class OrderItem {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 public Long productId;
 public String productName;
 public int quantity;
 public double unitPrice;
 public OrderItem(){}
}
