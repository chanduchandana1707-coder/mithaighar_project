package com.mithaighar.model;
import jakarta.persistence.*;
import java.time.LocalDateTime;
import java.util.*;
@Entity @Table(name="customer_orders")
public class Order {
 @Id @GeneratedValue(strategy=GenerationType.IDENTITY) public Long id;
 public String orderNumber,customerName,phone,address,status;
 public double total;
 public LocalDateTime createdAt=LocalDateTime.now();
 @OneToMany(cascade=CascadeType.ALL,orphanRemoval=true) public List<OrderItem> items=new ArrayList<>();
 public Order(){}
}
