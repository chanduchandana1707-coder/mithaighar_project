# MithaiGhar — Full-stack starter

Premium Indian sweets storefront built with React + Vite, Java 21 / Spring Boot, and MySQL.

## Requirements
- Node.js 20+
- Java 21+
- MySQL 8+

## 1. Database
Create the database:
```sql
CREATE DATABASE mithai_ghar;
```

## 2. Backend
Open a terminal in `backend`:
```bash
# Set your MySQL username/password as environment variables if needed:
# Windows PowerShell:
$env:DB_USERNAME="root"
$env:DB_PASSWORD="your_password"
# macOS/Linux:
export DB_USERNAME=root
export DB_PASSWORD=your_password

mvn spring-boot:run
```
API runs at http://localhost:8080. The app creates the product/order tables and seeds sample sweets automatically.

## 3. Frontend
Open another terminal in `frontend`:
```bash
npm install
npm run dev
```
Open the local URL printed by Vite (usually http://localhost:5173).

## Included
- Responsive premium storefront, product search and category filters
- Add/remove/update cart quantities
- Checkout form and order creation
- Order confirmation with generated order number
- Admin overview with product stock and recent orders
- Spring Boot REST API and MySQL persistence

## API
- `GET /api/products`
- `GET /api/orders`
- `POST /api/orders`
- `GET /api/orders/{id}`

This is a hackathon-ready starter, not a production payment system. Payment gateway, authentication, email/SMS, tax configuration, and deployment credentials must be integrated and tested before taking real orders.
